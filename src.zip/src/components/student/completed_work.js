import React from 'react'

export default function Completed_work() {
    return (
        <>
            <div className="col">
                <table className="table bg-white rounded shadow-sm  table-hover">
                    <thead>
                        <tr>
                            <th scope="col" width="50">#</th>
                            <th scope="col">Subject</th>
                            <th scope="col">Assignment</th>
                            <th scope="col">Description</th>
                            <th scope="col">Status</th>
                            <th scope="col">Rewards</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                    </tbody>
                </table>
            </div>
        </>
    )
}
