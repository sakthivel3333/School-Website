import React from 'react'

export default function Reward() {
  return (
    <div>
      This is a reward page
    </div>
  )
}
